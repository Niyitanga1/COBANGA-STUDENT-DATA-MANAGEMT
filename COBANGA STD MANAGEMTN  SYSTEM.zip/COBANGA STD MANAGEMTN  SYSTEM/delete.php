<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project 1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
else{
  
    
$sql = "SELECT * FROM user1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row

  echo "<center><table style=' border-collapse: collapse;
  width: 100%; padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;'  border=1   width='600' id='sig' cellspacing='0' cellpadding='0' border-spacing='0'><tr><th>first_name</th><th>last_name</th><th>class</th><th>id_number</th><th>district</th><th>secter</th><th>age</th><th>nationality</th><th>Action</th></tr>";
  while($row = $result->fetch_assoc()) {
    
    echo " <tr><td> " . $row["first_name"]. "</td><td>  " . $row["last_name"]. " </td><td> " . $row["class"]. " </td><td>  " . $row["id_number"]. " </td><td>  " . $row["district"]. "</td><td>   " . $row["secter"]. " </td><td>  " . $row["age"]. " </td><td>  " . $row["nationality"]. "</td><td><a href='deleteid.html' >Delete record</a></td></tr><br>";
    echo "</table>"; 

}
} else {
  echo "0 results";
}


}






$conn->close();

?>

