<html>
<head>


</head>
<body>
    <h1>ENTER THE ID OF THE STUDENT TO BE UPDATED</h1>

    <form action="updaterecord.php" method="post">

     Enter  the id : <input type="text" name="delid">
     <input type="submit" value="GO">

    </form>


</body>


</html>