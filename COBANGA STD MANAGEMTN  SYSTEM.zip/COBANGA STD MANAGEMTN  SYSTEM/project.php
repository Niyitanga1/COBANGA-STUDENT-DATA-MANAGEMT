<?php
$fname="localhost";
$lname="root";
$class="";
$db_name ="project 1";
//create connection
$conn new mysqli($fname,$lname,$class,,$db_name)
//check connection
if ($conn->connect_error);{
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$class = $_POST['class'];
$id number= $_POST['id number']
$district= $_POST['district']
$secter= $_POST['secter']
$age= $_POST['age']
$nationality= $_POST['nationality']
$sql = "INSERT INTO project 1(fname,lname,class,id number,district,secter,age,nationality)VALUES('$fname','$lname','$class','$id number','$district','$secter','$age','$nationality')";
if (mysqli_query($conn,$sql)){
    echo"create successfully";}
    else{
        echo"error:" .$sql . "<br>" .mysqli_error($conn);
    }
    ?>
    <html>
        <head>
            <title>project</title>
</head>
<body>
    <h1>successfully project</h1>
    <a href="insert.html">enter sab</a>