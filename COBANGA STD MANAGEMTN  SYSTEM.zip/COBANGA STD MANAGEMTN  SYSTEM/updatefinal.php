<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project 1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
else{
    echo "db  ok";
}

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$class=$_POST['class'];
$id=$_POST['id_number'];
$district=$_POST['district'];
$sector=$_POST['sector'];
$age=$_POST['age'];

$nationality=$_POST['nationality'];

$sql1 = "DELETE FROM user1 WHERE id_number=$id";

$sql = "INSERT INTO user1(first_name,last_name,class,id_number,district,secter,age,nationality)
VALUES ('$fname', '$lname', '$class','$id','$district','$sector','$age','$nationality')";
if ($conn->query($sql1) === TRUE) {
    echo "New record created successfully";
  }

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}






$conn->close();

?>