<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project 1";

$identinty=$_POST['delid'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
else{
  

    // sql to update  a record


$sql = "SELECT * FROM user1  where id_number=$identinty";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    echo "data  found";
  // output data of each row

  while($row = $result->fetch_assoc()) {
    

    $fname1= $row['first_name'];
    $lname1= $row['last_name'];
    $class1= $row['class'];
    $id_number1= $row['id_number'];
    $district1= $row['district'];
    $secter1= $row['secter'];
    $age1= $row['age'];
    $nationality1= $row['nationality'];

  


}
 
$conn->close();


}}








?>

<!DOCTYPE html>
<html>
<head>
<style>
  .form{
    box-sizing: border-box;
    background-color: darkgray;
    width: 300px;
    height: 40px;
    box-sizing: border-box;
    background-attachment: fixed;
    font-size: large
    
    
    
    font-family: Arial, Helvetica, sans-serif;
  }
 
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #04AA6D;
}
</style>
</head>
<body>
    <center><h1>COBANGA  STUDENT MANAGEMENT SYSTEM</h1></center>

<ul>
 <center > <li><a class="active" href="index.html">Home</a></li>
    <li><a href="insert.html">INSERT</a></li>
    <li><a href="delete.html">DELETE</a></li>
    <li><a href="update.html">UPDATE</a></li>
    <li><a href="view.html">VIEW  DATA</a></li></CEnter> 
</ul>
<br>
<br>
<br>
<br>
<br>
<br>

<center>


    <h1>Insert Student Data</h1></center><center>
      <form action="updatefinal.php" method="post">
        <table style="font-size: 25pt;">
          <tr>
            <td>First Name</td>
            <td><input type="text" name="fname" class="form" value="<?php echo $fname1; ?>"></td>
          
          <tr
          <tr>
          <td>last name </td>
          <td><input type="text" name="lname"class="form" value="<?php echo $lname1; ?>"></td>
        
           </tr>
           <tr>
          <td>class</td>
          <td><input type="text" name="class" class="form" value="<?php echo $class1; ?>"></td>
           </tr>
           <tr>
            <td> id number</td>
            <td><input type="text" name="id_number" class="form" value="<?php echo $id_number1; ?>"></td>
          
          </tr>
        
          <tr>
            <td>district </td>
            <td><input type="text" name="district" class="form" value="<?php echo $district1; ?>"></td>
          </tr>
        
          <tr>
            <td>secter</td>
            <td><input type="text" name="sector" class="form" value="<?php echo $secter1; ?>"></td>
          </tr>
        
          <tr>
        <td> age</td>
        <td><input type="text" name="age" class="form" value="<?php echo $age1; ?>"></td>
          </tr>
        
          <tr>
            <td> nationality</td>
            <td><input type="text" name="nationality" class="form" value="<?php echo $nationality1; ?>"></td>
          </tr>
          <tr>
            <td><input type="submit" name="yes" value="SAVE DATA"></td>
          </tr>
        
        </table>

        
      </form>

</center>
  
</body>




